
Data folder - contains the sample data for each table in CSV format
create_tables.sql - contains SQL script to create the database
indexes.sql - contains SQL script to create indexes
security.sql - contains SQL implementation of the security plan
optimization.sql - contains SQL scripts to explain optimization techniques used
final_dump_prod - contains a current dump of the production database
queries.sql - contains queries written for various use cases
transaction.sql - contains SQL script for transactions
backend folder - contains all the code for backend
